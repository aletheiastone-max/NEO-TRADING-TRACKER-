# Neo Trading Tracker
Android prototype matching the Matrix/CIA mock-up.

Features: animated boot sequence, Matrix code rain, radar scanner, searchable/followable USDT coins, live public market prices, ENTER/WAIT/NO ACTION analytical signal, ideal-bid estimate, live TradingView candles, and price-alert UI.

Signals are analytical indicators, not guaranteed outcomes or financial advice.

## Build
Push this project to GitHub. The included GitHub Actions workflow builds an installable debug APK.
